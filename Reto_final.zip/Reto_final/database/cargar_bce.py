import sys
import os

# Permite importar desde la carpeta transform
sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

import sqlite3

from transform.bce import (
    limpiar_pib_real,
    limpiar_pib_nominal,
    limpiar_iee,
    limpiar_petroleo,
    limpiar_riesgo_pais,
    limpiar_vab
)

conexion = sqlite3.connect("database/macroentorno.db")

print("Cargando PIB REAL...")
limpiar_pib_real().to_sql(
    "pib_real",
    conexion,
    if_exists="replace",
    index=False
)

print("Cargando PIB NOMINAL...")
limpiar_pib_nominal().to_sql(
    "pib_nominal",
    conexion,
    if_exists="replace",
    index=False
)

print("Cargando IEE...")
limpiar_iee().to_sql(
    "iee",
    conexion,
    if_exists="replace",
    index=False
)

print("Cargando PETROLEO...")
limpiar_petroleo().to_sql(
    "petroleo",
    conexion,
    if_exists="replace",
    index=False
)

print("Cargando RIESGO PAIS...")
limpiar_riesgo_pais().to_sql(
    "riesgo_pais",
    conexion,
    if_exists="replace",
    index=False
)

print("Cargando VAB...")
limpiar_vab().to_sql(
    "vab",
    conexion,
    if_exists="replace",
    index=False
)

conexion.close()

print("DATOS BCE CARGADOS CORRECTAMENTE")