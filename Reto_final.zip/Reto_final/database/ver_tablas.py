import sqlite3

conexion = sqlite3.connect("database/macroentorno.db")

cursor = conexion.cursor()

cursor.execute(
    "SELECT name FROM sqlite_master WHERE type='table';"
)

tablas = cursor.fetchall()

print("TABLAS EN LA BASE DE DATOS:\n")

for tabla in tablas:
    print(tabla[0])

conexion.close()