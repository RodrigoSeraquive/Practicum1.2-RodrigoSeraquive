import sqlite3

conexion = sqlite3.connect("database/macroentorno.db")

cursor = conexion.cursor()

# PIB REAL
cursor.execute("""
CREATE TABLE IF NOT EXISTS pib_real(
    anio INTEGER,
    pib_musd REAL,
    poblacion REAL,
    pib_percapita REAL,
    variacion_pct REAL
)
""")

# PIB NOMINAL
cursor.execute("""
CREATE TABLE IF NOT EXISTS pib_nominal(
    periodo DATE,
    pib_percapita_nominal_usd REAL
)
""")

# IEE
cursor.execute("""
CREATE TABLE IF NOT EXISTS iee(
    fecha DATE,
    iee_global REAL,
    comercio REAL,
    construccion REAL,
    manufactura REAL,
    servicios REAL
)
""")

# PETROLEO
cursor.execute("""
CREATE TABLE IF NOT EXISTS petroleo(
    periodo DATE,
    precio_petroleo_wti REAL
)
""")

# RIESGO PAIS
cursor.execute("""
CREATE TABLE IF NOT EXISTS riesgo_pais(
    periodo DATE,
    riesgo_pais_pb REAL
)
""")

# VAB
cursor.execute("""
CREATE TABLE IF NOT EXISTS vab(
    ciiu TEXT,
    cie TEXT,
    industria TEXT,
    anio_2018 REAL,
    anio_2019 REAL,
    anio_2020 REAL,
    anio_2021 REAL,
    anio_2022 REAL,
    anio_2023 REAL,
    anio_2024 REAL
)
""")

conexion.commit()

print("Tablas creadas correctamente")

conexion.close()