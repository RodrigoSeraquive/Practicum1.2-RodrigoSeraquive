from transform.bce import (
    limpiar_pib_real,
    limpiar_pib_nominal,
    limpiar_iee,
    limpiar_petroleo,
    limpiar_riesgo_pais,
    limpiar_vab
)

print("=== PIB REAL ===")
print(limpiar_pib_real().head())

print("\n=== PIB NOMINAL ===")
print(limpiar_pib_nominal().head())

print("\n=== IEE ===")
print(limpiar_iee().head())

print("\n=== PETROLEO ===")
print(limpiar_petroleo().head())

print("\n=== RIESGO PAIS ===")
print(limpiar_riesgo_pais().head())

print("\n=== VAB ===")
print(limpiar_vab().head())