import pandas as pd


def limpiar_pib_real():

    df = pd.read_excel(
        "datos/retropolacion_1965_2024p.xlsx",
        sheet_name="PIB pc real",
        skiprows=9
    )

    df.columns = [
        "anio",
        "pib_musd",
        "poblacion",
        "pib_percapita",
        "variacion_pct"
    ]

    df = df.dropna(how="all")

    return df


def limpiar_pib_nominal():

    df = pd.read_html(
        "datos/pib-per-cpita-nominal.xls"
    )[0]

    df.columns = [
        "periodo",
        "pib_percapita_nominal_usd"
    ]

    df["periodo"] = pd.to_datetime(df["periodo"])

    return df


def limpiar_iee():

    df = pd.read_excel(
        "datos/IEE_Nueva_Metodologia.xlsx",
        sheet_name="IEE",
        skiprows=6
    )

    df.columns = [
        "fecha",
        "iee_global",
        "comercio",
        "construccion",
        "manufactura",
        "servicios"
    ]

    # eliminar fila repetida de encabezados
    df = df.iloc[1:]

    # convertir fechas
    df["fecha"] = pd.to_datetime(
        df["fecha"],
        errors="coerce"
    )

    # eliminar notas y filas sin fecha válida
    df = df.dropna(subset=["fecha"])

    return df


def limpiar_petroleo():

    df = pd.read_html(
        "datos/precio-petrleo-wti.xls"
    )[0]

    df.columns = [
        "periodo",
        "precio_petroleo_wti"
    ]

    df["periodo"] = pd.to_datetime(df["periodo"])

    return df


def limpiar_riesgo_pais():

    df = pd.read_html(
        "datos/riesgo-pas.xls"
    )[0]

    df.columns = [
        "periodo",
        "riesgo_pais_pb"
    ]

    df["periodo"] = pd.to_datetime(df["periodo"])

    return df


def limpiar_vab():

    df = pd.read_excel(
        "datos/bam_mei_2018_2024p.xlsx",
        sheet_name="VAB",
        header=9
    )

    df = df.dropna(how="all")

    return df